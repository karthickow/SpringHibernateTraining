package com.sprsec.service;

import com.sprsec.model.User;

public interface UserService {
	
	public User getUser(String login);

}
