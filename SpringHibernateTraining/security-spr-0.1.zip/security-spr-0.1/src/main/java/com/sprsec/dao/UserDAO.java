package com.sprsec.dao;

import com.sprsec.model.User;

public interface UserDAO {
	
	public User getUser(String login);

}
